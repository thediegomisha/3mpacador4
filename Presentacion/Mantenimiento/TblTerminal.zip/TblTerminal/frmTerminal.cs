﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _3mpacador4.Presentacion.Mantenimiento;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using _3mpacador4;
using _3mpacador4.Logica;
using Devart.Data.MySql;

namespace _3mpacador4.Presentacion.Mantenimiento
{
    public partial class frmTerminal : Form
    {
        public int terminalId { get; private set; }

        public frmTerminal()
        {
            InitializeComponent();
            mostrarterminal();
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            frmTerminal2 F = new frmTerminal2();
            F.ShowDialog();
            mostrarterminal();
        }
       
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            this.Close();
        } 

        public void mostrarterminal()
        {
           
                MySqlCommand comando;
                try
                {
                    if (ConexionGral.conexion.State == ConnectionState.Closed){
                        
                        ConexionGral.conectar();
                    }

                    comando = new MySqlCommand("usp_tblterminal_select", ConexionGral.conexion);
                    comando.CommandType = (CommandType)4;

                    var adaptador = new MySqlDataAdapter(comando);
                    var datos = new DataTable();
                    adaptador.Fill(datos);

                {
                    var withBlock = this.datalistado;
                    if (datos.Rows.Count != 0)
                    {
                        var dr = datos.NewRow();
                        withBlock.DataSource = datos;                       
                    }
                    else
                    {
                        withBlock.DataSource = null;
                    }
                }

                ConexionGral.desconectar();
                } 
                catch (Exception ex)
                {
                    MessageBox.Show("Error " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
        }


        
        private void datalistado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (datalistado.Columns[e.ColumnIndex].Name == "Editar")
            {
                terminalId = Convert.ToInt32(datalistado.CurrentRow.Cells["idterminal"].Value.ToString());

                frmEditTerminal editForm = new frmEditTerminal();
                editForm.CargarDatosUsuario(terminalId);

                editForm.idTerminaledit = terminalId;

                editForm.ShowDialog();
                mostrarterminal();
            }

            if (datalistado.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                DialogResult r = MessageBox.Show("¿Está seguro que desea ELIMINAR este terminal?", "Advertencia", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

                if (r == DialogResult.OK)
                {
                    EliminarTerminal(terminalId);
                    mostrarterminal();
                }
            }
        }




        private void EliminarTerminal(int idTerminal)
        {
            MySqlCommand comando;
            try
            {
                if (ConexionGral.conexion.State == ConnectionState.Closed)
                {
                    ConexionGral.conectar();
                }

                comando = new MySqlCommand("DELETE FROM tblterminal WHERE idterminal = @idTerminal", ConexionGral.conexion);
                comando.Parameters.AddWithValue("@idTerminal", idTerminal);

                int filasAfectadas = comando.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    MessageBox.Show("Terminal eliminado exitosamente.", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el terminal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                ConexionGral.desconectar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al eliminar el terminal: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}