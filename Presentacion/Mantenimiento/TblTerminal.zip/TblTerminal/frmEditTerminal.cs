﻿using _3mpacador4.Logica;
using Devart.Data.MySql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3mpacador4.Presentacion.Mantenimiento
{
    public partial class frmEditTerminal : Form
    {
        public int idTerminaledit { get; set; }

        public frmEditTerminal()
        {
            InitializeComponent();

        }


        public void CargarDatosUsuario(int idTerminal)
        {
            try
            {
                if (ConexionGral.conexion.State == ConnectionState.Closed)
                {
                    ConexionGral.conectar();
                }

                MySqlCommand comando = new MySqlCommand("usp_tblterminal_mostrar", ConexionGral.conexion);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("p_idterminal", idTerminal);

                using (MySqlDataReader reader = comando.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        txtDescripcion.Text = reader["descripcion"].ToString();
                        txtFlagEstado.Text = reader["flag_estado"].ToString();
                    }
                }

                ConexionGral.desconectar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos del terminal: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void limpiarcampos()
        {
            try
            {
                txtDescripcion.Text = string.Empty;
                txtFlagEstado.Text = string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            MySqlCommand comando;
            try
            {
                if (ConexionGral.conexion.State == ConnectionState.Closed)
                {
                    ConexionGral.conectar();
                }

                comando = new MySqlCommand("usp_tblterminal_update", ConexionGral.conexion);
                comando.CommandType = CommandType.StoredProcedure;

                comando.Parameters.AddWithValue("p_idTerminal", idTerminaledit);
                comando.Parameters.AddWithValue("p_descripcion", txtDescripcion.Text);
                comando.Parameters.AddWithValue("p_flag_estado", txtFlagEstado.Text);
                
                int filasAfectadas = comando.ExecuteNonQuery();

                if (filasAfectadas > 0)
                {
                    MessageBox.Show("Terminal actualizado exitosamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar el terminal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
                ConexionGral.desconectar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al actualizar los datos del terminal: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
