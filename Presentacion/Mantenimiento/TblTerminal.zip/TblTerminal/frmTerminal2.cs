﻿using _3mpacador4.Logica;
using Devart.Data.MySql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3mpacador4.Presentacion.Mantenimiento
{
    public partial class frmTerminal2 : Form
    {
        public frmTerminal2()
        {
            InitializeComponent();
        }
               
        private void InsertarTerminal()
        {
            try
            {
                if (ConexionGral.conexion.State == ConnectionState.Closed)
                {
                    ConexionGral.conectar();
                }
                var comando = new MySqlCommand("INSERT INTO tblterminal (descripcion, flag_estado)" + '\r'
                        + "VALUES(@descripcion, @flag_estado)", ConexionGral.conexion);

                {
                    //DESCRPCION
                    if (!String.IsNullOrEmpty(txtDescripcion.Text))
                    {
                        comando.Parameters.AddWithValue("@descripcion", MySqlType.VarChar).Value = this.txtDescripcion.Text;
                    }
                    else
                    {
                        MessageBox.Show("Error, Ingrese una descripcion correcta", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    //FALGESTADO
                    if (!String.IsNullOrEmpty(txtFlagEstado.Text))
                    {
                        comando.Parameters.AddWithValue("@flag_estado", MySqlType.VarChar).Value = this.txtFlagEstado.Text;
                    }
                    else
                    {
                        MessageBox.Show("Error, Ingrese datos correctos", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    comando.ExecuteNonQuery();
                    MessageBox.Show("TERMINAL REGISTRADO SATISFACTORIAMENTE.", "Mensaje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiarcampos();

                    ConexionGral.desconectar();
                    return;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("TERMINAL NO REGISTRADO. \n" + ex.Message, "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    throw;
            }
        }

        private void limpiarcampos()
        {
            try
            {
                txtDescripcion.Text = string.Empty;
                txtFlagEstado.Text = string.Empty;
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            InsertarTerminal();
            this.Close();
           
        }
    }
}
